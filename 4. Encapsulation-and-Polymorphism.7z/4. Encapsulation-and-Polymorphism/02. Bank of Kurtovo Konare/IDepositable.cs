﻿namespace _02.Bank_of_Kurtovo_Konare
{
    public interface IDepositable
    {
        void Deposit(decimal amount);

    }
}