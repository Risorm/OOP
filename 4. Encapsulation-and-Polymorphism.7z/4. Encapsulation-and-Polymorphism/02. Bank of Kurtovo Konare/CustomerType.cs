﻿namespace _02.Bank_of_Kurtovo_Konare
{
    public enum CustomerType
    {
        Individual, Company
    }
}