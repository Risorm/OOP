﻿namespace _02.Bank_of_Kurtovo_Konare
{
    public interface IWithrawable
    {
        void Withdraw(decimal amount);
    }
}