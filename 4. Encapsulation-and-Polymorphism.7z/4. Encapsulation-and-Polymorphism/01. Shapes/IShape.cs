﻿namespace _01.Shapes
{
     interface IShape
     {
         double CalculateArea();
         double CalculatePerimeter();
     }
}
