﻿using System;
using TheSlum.GameEngine;

namespace TheSlum
{
    public class Program
    {
        static void Main(string[] args)
        {
            GameEngine.GameEngine engine = new GameEngine.GameEngine();
            engine.Run();
        }
    }
}
