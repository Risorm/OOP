﻿namespace _01.Customer
{
    enum CustomerType
    {
        Onetime, Regular, Golden, Diamond
    }
}
