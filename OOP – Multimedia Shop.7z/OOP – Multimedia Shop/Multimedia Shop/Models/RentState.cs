﻿
    enum RentState {Returned, Overdue, Pending}