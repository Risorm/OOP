﻿
public enum AgeRestriction {Minor, Teen, Adult}